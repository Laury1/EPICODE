import scrapy


class NewstitlespiderSpider(scrapy.Spider):
    name = "NewsTitleSpider"
    allowed_domains = ["www.sample.com"]
    start_urls = ["https://www.sample.com"]

    def parse(self, response):
        pass

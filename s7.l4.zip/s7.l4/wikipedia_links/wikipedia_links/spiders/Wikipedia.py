import scrapy


class WikipediaSpider(scrapy.Spider):
    name = "Wikipedia"

    start_urls = ['https://it.wikipedia.org']
    

    def parse(self, response):
        # Estrai tutti i link (elementi <a href="">) dalla pagina# Estrai tutti i link (elementi <a href="">) dalla pagina
        links=response.css("a::attr(href)").getall()
        for link in links:
          yield {"link":links}
        #contare i numeri di links nella pagina 
    #numero_links=len(links)
    #print(numero_links)
    #scrapy crawl Wikipedia -o links.csv
        
        

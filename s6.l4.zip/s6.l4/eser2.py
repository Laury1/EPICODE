from matplotlib import pyplot as plt
import pandas as pd


file_name = "./stockdata.csv"
dataset= pd.read_csv(file_name)

# Estrai i dati relativi all'andamento delle azioni di MSFT
aapl_data = dataset.loc[:19,"AAPL"]
print(aapl_data )
plt.plot(aapl_data,color="r",marker="o", linewidth=2,linestyle="--",markerfacecolor="k")
plt.xlabel("Data")
plt.ylabel("Valore")
plt.title("Azioni Apple")
plt.show()

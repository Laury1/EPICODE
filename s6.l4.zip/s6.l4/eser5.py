import pandas as pd
import matplotlib.pyplot as plt

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Carica il dataset
file_name="./titanic.csv"
df = pd.read_csv(file_name)

# Visualizzazione del numero di passeggeri per classe di imbarco
plt.figure(figsize=(8, 6))
sns.countplot(data=df, x='embarked')
plt.title('Numero di passeggeri per classe di imbarco')
plt.xlabel('Classe di imbarco')
plt.ylabel('Numero di passeggeri')
plt.show()

# Visualizzazione del numero di sopravvissuti per stato di sopravvivenza
plt.figure(figsize=(8, 6))
sns.countplot(data=df, x='alive')
plt.title('Numero di passeggeri sopravvissuti e deceduti')
plt.xlabel('Sopravvissuto')
plt.ylabel('Numero di passeggeri')
plt.show()

# Distribuzione delle tariffe
plt.figure(figsize=(8, 6))
sns.histplot(data=df, x='fare', bins=20, kde=True)
plt.title('Distribuzione delle tariffe')
plt.xlabel('Tariffa')
plt.ylabel('Numero di passeggeri')
plt.show()

# Boxplot delle età dei passeggeri rispetto alla classe di imbarco
plt.figure(figsize=(10, 6))
sns.boxplot(data=df, x='embarked', y='age')
plt.title('Distribuzione delle età dei passeggeri per classe di imbarco (Boxplot)')
plt.xlabel('Classe di imbarco')
plt.ylabel('Età dei passeggeri')
plt.show()

# Swarmplot delle età dei passeggeri rispetto alla classe di imbarco
plt.figure(figsize=(10, 6))
sns.swarmplot(data=df, x='embarked', y='age')
plt.title('Distribuzione delle età dei passeggeri per classe di imbarco (Swarmplot)')
plt.xlabel('Classe di imbarco')
plt.ylabel('Età dei passeggeri')
plt.show()

# Boxplot e lmplot rispetto alle colonne fare e survived
plt.figure(figsize=(12, 6))
sns.boxplot(data=df, x='survived', y='fare')
plt.title('Distribuzione delle tariffe rispetto a sopravvivenza (Boxplot)')
plt.xlabel('Sopravvissuto')
plt.ylabel('Tariffa')
plt.show()

plt.figure(figsize=(12, 6))
sns.lmplot(data=df, x='fare', y='survived')
plt.title('Distribuzione delle tariffe rispetto a sopravvivenza (lmplot)')
plt.xlabel('Tariffa')
plt.ylabel('Sopravvissuto')
plt.show()


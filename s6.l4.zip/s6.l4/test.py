def input_number(message: str):
    try:
        x = input(message)
        if x == "errore":
            raise ValueError("Hai inserito un testo sbagliato")
        if x:
            return float(x)
    except ValueError as e:
        print(str(e))
    finally:
        print("Continuo l'esecuzione della funzione")
    return None

def populate_list(l: []):
    x = 0
    while x != None:
        try:
            x = input_number("Nuovo numero: ")
            if x != None:
                l.append(x)
        except ValueError as e:
            print(str(e))
        except Exception as e:
            print(str(e))

my_list = []
populate_list(my_list)
print(my_list)

                        
import pandas as pd
import matplotlib.pyplot as plt

import pandas as pd
import matplotlib.pyplot as plt



# Scarica ifile_namel dataset e carica i dati
file_name="./election.csv"

df = pd.read_csv(file_name)

# Confronto dei voti totali presi dai tre candidati (come somma di tutti i distretti)
total_votes_per_candidate = df.groupby('candidate')['total_votes'].sum()

# Grafico a barre per i voti totali per candidato
plt.figure(figsize=(8, 6))
total_votes_per_candidate.plot(kind='bar', xlabel='Candidato', ylabel='Voti totali', title='Voti totali per candidato')
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig('total_votes_per_candidate.png', dpi=300)
plt.show()

# Confronto del numero di votanti per ogni distretto
voters_per_district = df.groupby('district')['voters'].sum()

# Grafico a barre per il numero di votanti per distretto
plt.figure(figsize=(10, 6))
voters_per_district.plot(kind='bar', xlabel='Distretto', ylabel='Numero di votanti', title='Numero di votanti per distretto')
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig('voters_per_district.png', dpi=300)
plt.show()

# Estrai i voti nei primi 4 distretti per ogni candidato
top_districts = df[df['district'].isin(['A', 'B', 'C', 'D'])]

# Pivot per ottenere i voti per distretto e candidato
top_districts_pivot = top_districts.pivot_table(index='district', columns='candidate', values='total_votes', aggfunc='sum')

# Grafico a barre comparativo per i voti nei primi 4 distretti per ogni candidato (formato appaiato)
plt.figure(figsize=(10, 6))
top_districts_pivot.plot(kind='bar', xlabel='Distretto', ylabel='Voti', title='Voti nei primi 4 distretti per candidato (Appaiato)')
plt.savefig('top_districts_comparison_grouped.png', dpi=300)
plt.show()

# Grafico a barre comparativo per i voti nei primi 4 distretti per ogni candidato (formato impilato)
plt.figure(figsize=(10, 6))
top_districts_pivot.plot(kind='bar', stacked=True, xlabel='Distretto', ylabel='Voti', title='Voti nei primi 4 distretti per candidato (Impilato)')

plt.savefig('top_districts_comparison_stacked.png', dpi=300)
plt.show()



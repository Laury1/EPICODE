from matplotlib import pyplot as plt
import pandas as pd

file_name = "./stockdata.csv"
dataset = pd.read_csv(file_name)

# Estrai i dati relativi all'andamento delle azioni di MSFT
msft_data = dataset["MSFT"]

# Visualizzazione dei dati
plt.plot(msft_data)
plt.title("Andamento delle azioni di Microsoft (MSFT)")
plt.xlabel("Data")
plt.ylabel("Prezzo Azioni")
plt.show()

# Estrai le prime 5 righe delle colonne MSFT e DATE
prime_5_righe = dataset[["Date", "MSFT"]].head()

# Utilizzare i dati estratti come ascisse e ordinate su un grafico mediante pyplot
plt.plot(prime_5_righe["Date"], prime_5_righe["MSFT"], marker="o")
plt.title("Andamento dei primi 5 giorni delle azioni di MSFT")
plt.xlabel("Data")
plt.ylabel("MSFT")
plt.show()

# Facciamo lo stesso per le ultime 5 righe del dataset
ultime_5_righe = dataset[["Date", "MSFT"]].tail()
plt.plot(ultime_5_righe["Date"], ultime_5_righe["MSFT"], marker="o")
plt.title("Andamento degli ultimi 5 giorni delle azioni di MSFT")
plt.xlabel("Data")
plt.ylabel("MSFT")
plt.show()



#y=[2,4,6,7,9,16,17]
#x=range(len(y))
#print(x)
#plt.plot(x,y, linewidth=4.0,color="r",marker="*",ls="--")
#plt.show()
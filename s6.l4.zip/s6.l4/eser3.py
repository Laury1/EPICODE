from matplotlib import pyplot as plt
import pandas as pd

file_name="./stockdata.csv"
data_f=pd.read_csv(file_name)
data_f.plot(figsize=(10,6))
plt.title("Andamento delle azioni")
plt.xlabel("data")
plt.ylabel("azioni")
plt.legend(loc="lower right")
plt.show()


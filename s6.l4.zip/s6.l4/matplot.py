from matplotlib import pyplot as plt
from numpy import random as rnd
import humanize as h
data=rnd.randint(0,100,10)
#x=[h.ordinati(i) for i in range (1,11)]
plt.plot(data,"c")
plt.show()
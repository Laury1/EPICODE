#Che tipo di struttura dati o matematica potrebbe rappresentare? 
# Notare che tutte le liste "interne" sono della stessa dimensione 
# Come facciamo per accedere ad un elemento in particolare?

mat = [[0, 1, 2, 3, 4],
       [5, 6, 7, 8, 9],
       [10, 11, 12, 13, 14]]
print(type(mat))
print(mat[1][3]) # mat[1]restituisce la seconda lista(sconda riga)
                 # mat[3]restituice il  quarto elemto della lista(quarta colona)
#mat[1][3] restituisce allora l elemento nella seconda riga e nella quarta colona della matrice
print(mat[2:]) 
print(mat[:-1])                  


import numpy as np

matrice = np.array([[5, 10, 15, 20, 25],
                    [30, 35, 40, 45, 50],
                    [55, 60, 65, 70, 75],
                    [80, 85, 90, 95, 100],
                    [105, 110, 115, 120, 125]])
valore_min=np.min(matrice)
valore_max=np.max(matrice)
matrice_trasformata=(matrice-valore_min)/(valore_max -valore_min)
print(matrice_trasformata)
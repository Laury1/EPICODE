import numpy as np

linear_data = np.array([x for x in range(27)])
#Lo ridimensioniamo mediante il metodo .reshape():

reshaped_data = linear_data.reshape((3, 3, 3))

#Quante dimensioni ha il nuovo array?
print(reshaped_data) # stampa una matrice tridimensionale 
print(len(reshaped_data))
elemento=reshaped_data[1,2,2] #1 rappresenta il secondo blocco,2 la terza riga e 2 la terza colonna
print(elemento)
print(reshaped_data.size)
print(reshaped_data.shape)

import numpy as np


li=[12,24,34,19,82,65]
ar=np.array(li)
print(type(ar))
print(ar.reshape(2,3))
print(np.split(ar,[2,3]))

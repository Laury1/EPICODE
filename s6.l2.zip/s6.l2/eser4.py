#Per calcolare i punti esatti in cui inserire i rivetti su una struttura metallica di
# lunghezza 28.75 cm, con un rivetto all'inizio, uno alla fine e 15 rivetti intermedi,
# puoi utilizzare NumPy per generare una sequenza di punti equidistanti lungo la lunghezza 
# della struttura. Ecco come puoi farlo:

import numpy as np
lunghezza_stru=28.75
lunghezza_stru=15
#Calcola la distanza tra i rivetti intermedi
dist_tra_rivetti=lunghezza_stru/(lunghezza_stru + 1)
#Calcola i punti esatti in cui inserire i rivetti
punti_rivetti=np.arange(0,lunghezza_stru + dist_tra_rivetti ,dist_tra_rivetti)

print("Punti esatti per inserire i rivetti:")
for punto in punti_rivetti:
    print(round(punto, 2), "cm")


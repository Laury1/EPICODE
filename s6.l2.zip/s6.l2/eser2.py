#Come facciamo per accedere ai singoli elementi?
import numpy as np
mat = [[0, 1, 2, 3, 4], 
       [5, 6, 7, 8, 9] ,
       [10, 11, 12, 13, 14]] 

#in un array NumPy:
mat= np.array(mat)
print(type(mat))
elemento=mat[2,3] 
elemento1=mat[2,4]
print(elemento) #restituisce l' elemento alla terza riga e  quarta colona
print(elemento1)
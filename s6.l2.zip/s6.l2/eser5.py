import numpy as np
matrice=[[1,2,3],[4,5,6],[7,8,9]]
         
 #creare un ndarray con le syesse dimensioni
      # Creare un ndarray vuoto con le stesse dimensioni della matrice esistente
forma = np.shape(matrice)
nuovo_array = np.empty(shape=forma, dtype=int)

# Inserire i valori nelle posizioni adatte
for i in range(forma[0]):
    for j in range(forma[1]):
        nuovo_array[i, j] = matrice[i][j]

print(nuovo_array)

#2 metodo:
#Creare una lista di liste e poi effettuare un casting


# Matrice esistente
matrice = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]

# Creare un ndarray effettuando un casting dalla lista di liste
nuovo_array = np.array(matrice)

print(nuovo_array)   
-- create a table
CREATE TABLE students (
 id INTEGER PRIMARY KEY,
 name TEXT NOT NULL,
  gender TEXT NOT NULL
);
-- insert some values
INSERT INTO students VALUES (1, 'Ryan', 'M');
INSERT INTO students VALUES (2, 'Joanna', 'F');
-- fetch some values
SELECT * FROM students WHERE gender = 'F';
--create table DISCO
CREATE TABLE DISCO(
    NroSerie integer,
    TitoloAlbum VARCHAR(50),
    Anno INTEGER,
    Prezzo VARCHAR(255)
    );
--create table CONTIENE
CREATE TABLE CONTIENE(
    NroSerieDisco INTEGER,
    CodiceReg VARCHAR(50),
    NroProg INTEGER
    );
--create table ESECUZIONE
CREATE TABLE ESECUZIONE(
    CodiceReg VARCHAR(50) PRIMARY KEY,
    TitoloCanz TEXT NOT NULL,
    Anno INTEGER
    );
--create table AUTORE
CREATE TABLE AUTORE (
 Nome TEXT NOT NULL ,
    TitoloCanzone TEXT NOT NULL
    );
--create table CANTANTE
CREATE TABLE CANTANTE(
    NomeCantante VARCHAR(50) PRIMARY KEY,
    CodiceReg VARCHAR(50)
    );

INSERT INTO DISCO VALUES(NroSerie , TitoloAlbum,Anno ,
Prezzo) ;
 
INSERT INTO DISCO VALUES (1,'la vita',2000,'50£');
(2,'amore',2003,'30£'),
(3,'la tecnologia',null,'14'),
 (4,'the girl ',2023,'25£'),
(5,'all the time',2022,'45£'),
(6,'i am proud',NULL,'15£'),
(10,'speranza',2016,'15£');  

INSERT INTO CONTIENE (NroSerieDisco ,CodiceRegp ,NroProg )
    VALUES
(4,NY22',20),
(1,'ML1',14),
(2,'BGM3',10),
(3,'FRZ0',13),
(10, 'RM1',16),
(5,'YD2',10),
(6,'PG1',22);

INSERT INTO ESECUZIONE  (CodiceReg ,TitoloCanz ,Anno )
    VALUES
('YD2','seriously',2016),
('ML1','la vita è bella',2000), 
('BGM3','amore mio',2003),
('RM1','una stella',2016),
('NY','i like stay with you',2023),
('PG1','hello',null),
('FRZ0','seriously',NULL);

INSERT INTO AUTORE (Nome ,TitoloCanzone )
VALUES
('Andrea bocelli', 'amore mio'),
('Laura pausini','la vita è bella'),
('Davido','seriously'),
('Daniel kiss','seriously'),
    ('Gims','hello');

    INSERT INTO CANTANTE (NomeCantante ,CodiceReg)
    VALUES
    ('Davido','FRZ0'),
    ('Daniel kiss','FRZ0');
     
  SELECT DISTINCT A1.Nome AS Autore1, A2.Nome AS Autore2, E.TitoloCanz
FROM AUTORE A1
JOIN ESECUZIONE E ON A1.CodiceReg = E.CodiceReg
JOIN AUTORE A2 ON E.TitoloCanz = A2.TitoloCanzone AND A1.Nome <> A2.Nome;
WHERE   A1.Nome LIKE 'D’%'AND A2.Nome LIKE 'D’%'; 
    
  SELECT DISTINCT D.TitoloAlbum  
FROM DISCO AS D
    JOIN CONTIENE AS C ON D.NroSerie=C.NroSerieDisco
LEFT JOIN ESECUZIONE AS E ON C.CodiceReg=E.CodiceReg
WHERE E.Anno IS NULL;
    

    
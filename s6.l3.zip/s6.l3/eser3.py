import pandas as pd

# Caricamento del file CSV
url = "https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data"
iris_df = pd.read_csv(url, header=None)  # Non specificando 'header', pandas non utilizzerà la prima riga come header

import pandas as pd 
import numpy as np
 
 
file_name="./iris.data.csv"
nomi_colonne = ['sepal_length', 'sepal_width', 'petal_length', 'petal_width', 'class'] 
iris=pd.read_csv(file_name,header=0,names=nomi_colonne)

#stampa i primi cinque righe
prime_5_righe=iris.iloc[:5]
ultime_10_righe=iris.iloc[-10:]
print("le prime cinque righe sono:",prime_5_righe)
print("le prime cinque righe sono:",ultime_10_righe)

import pandas as pd
import numpy as np


file_name="./wine.csv"
data=pd.read_csv(file_name, sep=",",encoding="iso-8859-15",header=0)
print(data)
print(data.describe())
print(data.count())
#Calcola la media lungo l'asse delle righe (axis=1) 
# per tutti i valori numerici presenti nei dati.
media=data.mean(axis=1,numeric_only=True)
mediana=data.median(axis=1 ,numeric_only=True)
# Calcola la moda lungo l'asse delle colonne (axis=0)
# per tutti i valori numerici presenti nei dati
moda=data.mode(axis=0,numeric_only=True)
quartili=data.quantile([0.25,0.50,0.75],numeric_only=True)
print("la media è :",media)
print("la mediana è :",mediana)
print("la moda è :",moda)
print("i quartili sono :",quartili)



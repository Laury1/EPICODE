import pandas as pd
import numpy as np

file_name="./iris.data.csv"

data1=pd.read_csv(file_name,sep=",",encoding="iso-8859-15" ,header=0)


#assegniamo i nomi delle colonne al DataFrame
nomi_colonna=["sepal_lenght","sepal_width","petal_lenght","pstal_wigth","class"]
data1.columns=nomi_colonna

#stampiamo i primi cinque righe
print("i primi cinque righe sono:")
conteggio=data1.iloc[:5]
print(conteggio)
print("\nnomi_colonna:")
print(data1.columns)
print(data1.shape)
print(data1.loc[2:20])



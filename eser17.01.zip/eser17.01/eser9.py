guadagni=[100,90,70,40,50,90,120,80,20,50]
lunghezza=len(guadagni)
indice=0
somma_guadagni=0
while indice<lunghezza:
    somma_guadagni +=guadagni[indice]
    indice +=1
    
if len(guadagni)>0:
    media = somma_guadagni/lunghezza
print("la media dei guadagni è: ",media)
    
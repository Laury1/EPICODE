#Calcolare e stampare tutte le potenze di 2 minori di 25000.
espo=0
while 2**espo<2500:
  print("2^",espo,"=",2**espo)
  espo +=1

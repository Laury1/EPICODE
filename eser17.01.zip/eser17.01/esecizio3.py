#  3  i primi 10 potenze di 2 utilizzando while
  
espo=0
while espo<=10:
    
   print("2^",espo,"=",2**espo) 
   espo +=1 
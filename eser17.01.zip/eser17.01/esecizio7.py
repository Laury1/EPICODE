stringa=input("inserire una stringa: ")
lunghezza=len(stringa)
if lunghezza<6:
 print(stringa[:3],"...",stringa[-3:])
else: 
  print(stringa)


#funzione fibonacci
numero1=1
numero2=2
fibo=[1,1]
conteggio=1
while conteggio <=10:
    numero_pross=numero1+numero2
    fibo.append(numero_pross)
    numero1=numero2numero2=numero_pross
    conteggio +=1
print("i dieci primi numeri di fibo sono:" ,fibo)

# 1 stampare ogni carattere della stringa utilizzando  while
nome_scuola="Epicode"
indice =0
while indice< len(nome_scuola):
    print(nome_scuola[indice])
    indice +=1
    
  #2 stampare a video tutti i numeri da 0 a 20 utilizzando il costrutto while 
num=0
while num<=20:
      print("il numero è:",num)
      num +=1
      
 #  3  i primi 10 potenze di 2 utilizzando while
  
espo=0
while espo<=10:
    
   print("2^",espo,"=",2**espo) 
   espo +=1 
               


#Calcolare e stampare tutte le potenze di 2 minori di 25000.
espo=0
while 2**espo<2500:
  print("2^",espo,"=",2**espo)
  espo +=1




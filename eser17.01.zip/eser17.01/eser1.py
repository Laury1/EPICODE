# 1 stampare ogni carattere della stringa utilizzando  while
nome_scuola="Epicode"
indice =0
while indice< len(nome_scuola):
    print(nome_scuola[indice])
    indice +=1
#2 stampare a video tutti i numeri da 0 a 20 utilizzando il costrutto while 
num=0
while num<=20:
      print("il numero è:",num)
      num +=1
#4 calcolare e stampare i primi N potenze di 2 con while
# Chiedi all'utente di inserire il valore di N
N = int(input("Inserisci il valore di N: "))

esponente = 0
contatore = 0

while contatore < N:
    risultato = 2 ** esponente
    print(f"2^{esponente} = {risultato}")
    esponente += 1
    contatore += 1

#Abbiamo due liste, una di studenti e una di corsi: 
studenti =["Alex", "Bob", "Cindy", "Dan", "Emma", "Faith", "Grace", "Henry"] 
corsi = ["Cybersecurity", "Data Analyst", "Backend", "Frontend", "Data Analyst", "Backend"]
studenti_new=["Emma","Faith","Grace","Henry"]
corsi_new=["data analyst","backend","frontend","cybersecurity"]
indice=0
while indice<len(studenti_new):
    studente=studenti_new[indice]
    corso=corsi_new[indice]
if studente not in studenti:
     studenti.append(studente)
if studenti.index(studente) >= len(corsi):
        corsi.append(corso)
indice += 1
if len(corsi) == len(studenti):
    print(corsi)  
 


      

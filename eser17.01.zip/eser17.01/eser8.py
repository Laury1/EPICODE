#Memorizza e stampa tutti i divisori di un numero dato in input.
numero=int(input("inserisci un numero: "))
divisori=[]
for i in range(2, numero+1):
    while numero % i== 0:
        divisori.append(i)
    numero //=i
print("i divisori di{numero} sono: {divisori}")

#Abbiamo due liste, una di studenti e una di corsi: 
studenti =["Alex", "Bob", "Cindy", "Dan", "Emma", "Faith", "Grace", "Henry"] 
corsi = ["Cybersecurity", "Data Analyst", "Backend", "Frontend", "Data Analyst", "Backend"]
studenti_new=["Emma","Faith","Grace","Henry"]
corsi_new=["data analyst","backend","frontend","cybersecurity"]
indice=0
while indice<len(studenti_new):
    studente=studenti_new[indice]
    corso=corsi_new[indice]
if studente not in studenti:
     studenti.append(studente)
if studenti.index(studente) >= len(corsi):
        corsi.append(corso)
indice += 1
if len(corsi) == len(studenti):
    print(corsi) 
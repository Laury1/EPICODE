#Scrivere una funzione che, data una lista di numeri, fornisca in output il minimo e
# il massimo (possiamo usare o meno le funzioni min() e max() nel corpo).

def min_max(lista):
    minimo=massimo=lista[0]
    for numero in lista:
        if numero<minimo:
            minimo=numero
        elif numero>massimo:
            massimo=numero    
    return minimo,massimo  
lista=[3,5,8,2,9]
minimo,massimo=min_max(lista)
print("il minimo è:",minimo,"il massimo +:",massimo)

     
            
            



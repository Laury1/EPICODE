#Creiamo un dizionario che assegni ad ogni proprietario la sua auto,
# sapendo che:
# • Ada guida una Punto 
# • Ben guida una Multipla 
# • Charlie guida una Golf 
# • Debbie guida una 107 Stampiamo il dizionario per intero,
# e poi l'auto associata a Debbie.


proprietari_auto={"Ada":"Punto",
                  "Ben":"Multipla",
                  "Charle":"Golf",
                  "Debbie":"107"
                  }
print(proprietari_auto)
print("l'auto di Debbie è:",proprietari_auto["Debbie"])

auto_debbie = proprietari_auto.get('Debbie', 'Proprietario non trovato')
print(f"\nL'auto di Debbie è una {auto_debbie}")

#Scrivere una funzione che, data una lista di numeri, fornisca in output i tre 
# numeri più grandi; gestire il caso in cui la lista sia più corta di tre, e quando uno
# o più dei numeri selezionati sono uguali.

def numeri_grandi(lista):
    nl = []
    for i in lista:
        if i not in nl:
            nl.append(i)
    # possiamo prima ordinare la lista
    nl.sort()
    # poiché ci servono i 3 più grandi
    tregrandi = nl[-3:]
    return tregrandi

l = [423,6435,847,234, 6435]
x = numeri_grandi(l)
print("I tre più grandi sono", x)

  
       
    
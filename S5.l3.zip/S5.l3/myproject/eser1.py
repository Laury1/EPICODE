#fare gli esercizi di ieri utilizzando l'istruzione for
#Abbiamo una lista con i guadagni degli ultimi 12 mesi: 
 #   guadagni = [100, 90, 70, 40, 50, 80, 90, 120, 80, 20, 50, 50]
 #   usando un costrutto while, calcolare la media dei guadagni e stamparla a video.
guadagni = [100, 90, 70, 40, 50, 80, 90, 120, 80, 20, 50, 50]
somma=0
lughezza=len(guadagni)
for guadagno in guadagni:
    somma +=guadagno
print("la media è:", somma/len(guadagni))
    
  #Memorizza e stampa tutti i divisori di un numero dato in input. Esempio: 
  # 
  # • input: 150 • output: [2, 3, 5, 5]  
     
i=0
numero=int(input ("inserire un numero: "))
divisori=[]
for i in range(2,numero +1):
 if numero%i ==0:
  divisori.append(i)
print("i divisori sono:",divisori)

#Abbiamo una lista di stringhe di prezzi in dollari, che erroneamente sono stati scritti con il simbolo dell'euro:
# prezzi = ["100 €", "200 €", "500 €", "10 €", "50 €", "70 €"]
# cambiare il simbolo dell'euro (€) in quello del dollaro ($) per ogni stringa nella lista; il risultato sarà memorizzato in un'altra lista.

prezzi = ["100 €", "200 €", "500 €", "10 €", "50 €", "70 €"]
prezzi_new=[]
for prezzo in prezzi:
    prezzo_new=prezzo.replace("£","$")
    prezzi_new.append(prezzo_new)
print(prezzi_new)

 
#Scrivere una funzione che in input acquisisce una lista di numeri e un numero K; 
# in output, dovrà restituire la media di tutti i numeri nella lista maggiori o uguali a K; se non ce ne dovesse essere nessuno,
# dovrà stampare a schermo un messaggio adeguato.

def media_numeri(lista,k):
    somma= 0
    count=0
    for i in range(0,len(lista)):
        if lista[i]>=k:
            somma=lista[i]
            count +=1
    if count== 0:
        return 0
          
    media=float(somma/count) 
    return media
         
lista=[12,34,85,23,26]  
k=13
x=media_numeri(lista,k)
print(x)      
        
    



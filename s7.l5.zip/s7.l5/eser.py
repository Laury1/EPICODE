import numpy as np
import pandas as pd
import matplotlib.pyplot as plt



file_name="./dataset_climatico.csv"
df=pd.read_csv(file_name)
print(df.shape)
df.dropna(inplace=True)
print(df)
#Applicare la normalizzazione min _max alla temperatura_media, 
# precipitazioni, umidità e velocità_vento per standardizzarle.
min_tem=df["temperatura"].min()
max_tem=df["temperatura"].max()
range1=max_tem - min_tem
df["temperatura_normalizzato"]=(df["temperatura"]- min_tem)/range1
min_prec=df["precipitazioni"].min()
max_prec=df["precipitazioni"].max()
range2=max_prec - min_prec
df["precipitazioni_normalizzato"]=(df["precipitazioni"] - min_prec )/range2


min_umid=df["umidita"].min()
max_umid=df["umidita"].max()
range3=max_umid - min_umid
df["umidita_normalizzato"]=(df["umidita"] - min_umid)/range3

min_veloc_vento=df[" velocita_vento "].min()
max_veloc_vento=df["velocita_vento "].max()
range4=max_veloc_vento - min_veloc_vento
df["velocita_vento_normalizzato"]=(df["velocita_vento"] -min_veloc_vento )/range4

print(df)








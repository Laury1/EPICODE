import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn  as sns



file_name="./dataset_climatico.csv"
df=pd.read_csv(file_name)
print(df.shape)
#pulizia dei dati
df.dropna(inplace=True)

# Normalizzazione Z-score
#df["temperatura_media"]=df["temperatura"].mean()
col_a_nornalizzare = ['temperatura_media', 'precipitazioni', 'umidita', 'velocita_vento']
df[col_a_nornalizzare] = (df[col_a_nornalizzare] - df[col_a_nornalizzare].mean()) / df[col_a_nornalizzare].std()

#Analisi Esplorativa dei Dat
df_mean=df[col_a_nornalizzare].mean()
df_mediana=df[col_a_nornalizzare].median()
df_deviazione_standard=df[col_a_nornalizzare].describe()

#print(df)
#Creare grafici (istogrammi, box plots) per visualizzare
# la distribuzione di ciascuna variabile normalizzata

selected_variables = ['temperatura_media']
# Creazione di istogrammi
for column in selected_variables:
    if column in df.columns:
        plt.figure(figsize=(8, 6))
        sns.histplot(df[column], kde=True)
        plt.title(f'Istogramma {column}')
        plt.xlabel(column)
        plt.ylabel('Frequenza')
        plt.show()

#un altro motodo per aver per  ogni colonna
for column in col_a_nornalizzare:
    plt.figure(figsize=(8, 6))
    sns.histplot(df[column], kde=True)
    plt.title(f'Distribuzione di {column}')
    plt.xlabel(column)
    plt.ylabel('Frequenza')
    plt.show()   
         
 # Creazione di box plots per 
 # visualizzare la distribuzione di ciascuna variabile
plt.figure(figsize=(10, 6))
df.boxplot(column=col_a_nornalizzare)
plt.title('Box plot delle variabili normalizzate')
plt.ylabel('Valore normalizzato')
plt.show()       


#Analisi di Correlazione:
# Seleziona solo le colonne numeriche escludendo 'data_osservazione' e 'stazione_meteorologica'
numeric_columns=["temperatura_media","precipitazioni","umidita","velocita_vento"]
colonna_df=df[numeric_columns]
# Calcola la correlazione
corr_tra_var = colonna_df.corr()
plt.figure(figsize=(10, 10))
sns.heatmap(corr_tra_var,annot=True, cmap='coolwarm', fmt=".2f", linewidths=0.5)
plt.title('Correlazione tra variabili meteorologiche')
plt.show()

#Se osservi una correlazione significativa tra temperatura e umidità, 
# significa che quando la temperatura aumenta, l'umidità tende a aumentare o diminuire. 
# Puoi identificare la correlazione tra queste due 
# variabili guardando il valore annotato nella cella corrispondente nella heatmap.



